<!DOCTYPE html>
<html>
<head>
	<title>Tutorial Laravel #4 : passing data controller ke view laravel- www.malasngoding.com</title>
</head>
<body>
 <h1>Tutorial laravel</h1>
 <a href="https://www.malasngoding.com/category/laravel">www.malas ngoding.com</a>
 <br>

 <p>Nama : <?php echo e($nama); ?></p>
 
 <p> Pelajaran</p>
 <ul>

	 <?php $__currentLoopData = $matkul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

	 <li><?php echo e($m); ?></li>

	 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	 
 </ul>

</body>
</html>

 